<?php

	/**
	 * The QJqTextBox plugin.
	 * Use this class to implement your custom logic, or
	 * override the default behaviour.
	 */

	/**
	 * The QJqTextBox plugin.
	 * 
	 * Use this class to implement your custom logic, or
	 * override the default behaviour.
	 */
	class QJqTextBox extends QJqTextBoxBase
	{
	}
?>